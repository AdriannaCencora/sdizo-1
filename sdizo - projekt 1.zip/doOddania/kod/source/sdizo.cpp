// sdizo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "./controllers/appController/AppController.h"

using namespace std;

int main()
{
	AppController app;
	app.Run();
    return 0;
}

