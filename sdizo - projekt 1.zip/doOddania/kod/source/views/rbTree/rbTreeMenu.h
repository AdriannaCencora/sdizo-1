#pragma once
#include "..\genericView\GenericView.h"
class rbTreeMenu :
	public GenericView
{
public:
	rbTreeMenu() = default;
	virtual ~rbTreeMenu() = default;

	virtual void print();


};

