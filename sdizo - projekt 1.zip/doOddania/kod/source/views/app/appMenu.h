#pragma once
#include "../genericView/GenericView.h"
class appMenu :
	public GenericView
{
public:
	virtual ~appMenu() {};
	virtual void print();
};

