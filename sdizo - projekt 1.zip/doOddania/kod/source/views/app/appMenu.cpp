#include "stdafx.h"
#include "appMenu.h"

using namespace std;

void appMenu::print()
{
	cout << "Projekt 1 ze Struktur danych i z�o�ono�ci obliczeniowej" << endl;
	cout << "==== Menu g��wne ===" << endl;
	cout << "1.Tablica" << endl;
	cout << "2.Lista dwustronna" << endl;
	cout << "3.Kopiec" << endl;
	cout << "4.Drzewo BST" << endl;
	cout << "5.Drzewo czerwono-czarne" << endl;
	cout << "6.Przeprowad� pomiary dla wszystkich struktur" << endl;
	cout << "0.Wyjscie" << endl;
}
