#pragma once
#include "../genericView/GenericView.h"
class heapMenu :
	public GenericView
{
public:
	virtual ~heapMenu() {};
	virtual void print();
};

