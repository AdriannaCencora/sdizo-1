#pragma once
#include "../genericView/GenericView.h"
class listMenu :
	public GenericView
{
public:
	virtual ~listMenu() {};
	virtual void print();
};

