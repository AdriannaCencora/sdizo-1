#pragma once
#include "../genericView/GenericView.h"
class ArrayMenu :
	public GenericView
{
public:
	virtual ~ArrayMenu() {};
	virtual void print();
};

