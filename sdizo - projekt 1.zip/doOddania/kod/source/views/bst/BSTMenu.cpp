#include "stdafx.h"
#include "BSTMenu.h"

using namespace std;

void BSTMenu::print()
{
	cout << "------Drzewo BST------" << endl;
	cout << "1.Wczytaj z pliku" << endl;
	cout << "2.Usun" << endl;
	cout << "3.Dodaj" << endl;
	cout << "4.Znajdz" << endl;
	cout << "5.Utworz losowo" << endl;
	cout << "6.Wyswietl" << endl;
	cout << "7.Test (pomiary)" << endl;
	cout << "8.Wyczy��" << endl;
	cout << "9.R�wnowa�" << endl;
	cout << "0.Powrot do menu" << endl;
}
